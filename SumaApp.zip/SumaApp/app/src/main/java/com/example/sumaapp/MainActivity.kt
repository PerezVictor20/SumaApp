package com.example.sumaapp
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Referencias a los elementos de la interfaz
        val numero1 = findViewById<EditText>(R.id.numero1)
        val numero2 = findViewById<EditText>(R.id.numero2)
        val btnSumar = findViewById<Button>(R.id.btnSumar)
        val textoResultado = findViewById<TextView>(R.id.textoResultado)
        // Configurar el botón para realizar la suma
        btnSumar.setOnClickListener {
            val num1 = numero1.text.toString().toDoubleOrNull()
            val num2 = numero2.text.toString().toDoubleOrNull()
            if (num1 != null && num2 != null) {
                val suma = num1 + num2
                textoResultado.text = "Resultado: $suma"
            } else {
                textoResultado.text = "Por favor, ingresa números válidos"
            }
        }
    }
}
